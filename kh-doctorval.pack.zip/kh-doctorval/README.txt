Teleports coords.

enterPos = vector3(-282.38, 811.6, 122.55),
exitPos = vector3(-283.66, 811.39, 122.65),